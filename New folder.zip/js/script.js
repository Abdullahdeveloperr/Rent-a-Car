// ===============================
// DRIVEKHI — FULL SCRIPT (FIXED)
// ===============================


// ===== NAV SCROLL =====
const navbar = document.getElementById('navbar');

window.addEventListener('scroll', () => {
  navbar?.classList.toggle('is-scrolled', window.scrollY > 50);
});


// ===== MOBILE NAV =====
const navToggle = document.getElementById('navToggle');
const navMenu = document.getElementById('navMenu');

navToggle?.addEventListener('click', () => {
  navMenu.classList.toggle('is-open');
});

navMenu?.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    navMenu.classList.remove('is-open');
  });
});


// ===== SMOOTH SCROLL =====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', e => {
    e.preventDefault();
    const target = document.querySelector(anchor.getAttribute('href'));
    if (target) target.scrollIntoView({ behavior: 'smooth' });
  });
});


// ===== SCROLL ANIMATION =====
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add('is-visible');
  });
}, { threshold: 0.1 });

document.querySelectorAll('[data-animate]').forEach(el => observer.observe(el));


// ===============================
// FLEET DATA SYSTEM
// ===============================
let allCars = [];
let activeFilter = "all";

const fleetGrid = document.getElementById('fleetGrid');
const filterBtns = document.querySelectorAll('.filter-btn');
const fleetSort = document.getElementById('fleetSort');


// ===== FETCH JSON =====
fetch('js/cars.json')
  .then(res => res.json())
  .then(data => {
    allCars = data;
    updateFleet();
  });


// ===============================
// RENDER (FULL FEATURE RESTORED)
// ===============================
function renderCars(data) {

  fleetGrid.innerHTML = "";

  data.forEach(car => {

    fleetGrid.innerHTML += `

      <div class="car-card"
        data-category="${car.category}"
        data-price="${car.price}"
        data-popular="${car.popular || 0}">

        ${car.badge ? `
          <div class="car-card__badge ${car.badgeClass || ''}">
            ${car.badge}
          </div>
        ` : ''}

        <div class="car-card__img">
          <div class="car-emoji">${car.emoji || "🚗"}</div>
          <div class="car-card__rating">⭐ ${car.rating}</div>
        </div>

        <div class="car-card__info">

          <div class="car-card__head">

            <div>
              <h3>${car.name}</h3>
              <p class="car-card__type">${car.type}</p>
            </div>

            <div class="car-card__availability ${car.availabilityClass || ''}">
              ${car.availability || "Available"}
            </div>

          </div>

          <div class="car-card__specs">
            <span>⛽ ${car.fuel}</span>
            <span>🪑 ${car.seats}</span>
            <span>❄️ ${car.ac}</span>
            <span>🎵 ${car.music}</span>
          </div>

          <div class="car-card__features">
            ${(car.features || []).map(f => `
              <span>✓ ${f}</span>
            `).join('')}
          </div>

          <div class="car-card__price-row">

            <div>
              <span class="price">PKR ${car.price}</span>
              <span class="price-per">/day</span>
            </div>

            <button class="btn btn--icon" onclick="wishlistToggle(this)">
              🤍
            </button>

          </div>

          <a href="https://wa.me/92312345678?text=I want to book ${car.name}"
            class="btn btn--primary btn--full"
            target="_blank">
            📲 Book Now
          </a>

        </div>

      </div>

    `;
  });
}


// ===============================
// FILTER + SORT (FIXED)
// ===============================
function updateFleet() {

  let filtered = [...allCars];

  // FILTER
  if (activeFilter !== "all") {
    filtered = filtered.filter(car => car.category === activeFilter);
  }

  // SORT
  const sort = fleetSort?.value || "default";

  if (sort === "price-asc") {
    filtered.sort((a, b) => a.price - b.price);
  }

  if (sort === "price-desc") {
    filtered.sort((a, b) => b.price - a.price);
  }

  if (sort === "popular") {
    filtered.sort((a, b) => (b.popular || 0) - (a.popular || 0));
  }

  renderCars(filtered);
}


// ===== FILTER BUTTONS =====
filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {

    filterBtns.forEach(b => b.classList.remove('is-active'));
    btn.classList.add('is-active');

    activeFilter = btn.dataset.filter;

    updateFleet();
  });
});


// ===== SORT =====
fleetSort?.addEventListener('change', updateFleet);


// ===============================
// WISHLIST
// ===============================
function wishlistToggle(btn) {
  btn.textContent = btn.textContent === "🤍" ? "❤️" : "🤍";
}


// ===============================
// MODAL CLOSE ESC
// ===============================
document.addEventListener('keydown', e => {
  if (e.key === "Escape") {
    document.querySelector('.modal')?.classList.remove('is-open');
  }
});